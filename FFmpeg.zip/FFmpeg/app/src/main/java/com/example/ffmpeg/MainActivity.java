package com.example.ffmpeg;

import androidx.appcompat.app.AppCompatActivity;

import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.widget.MediaController;
import android.widget.TextView;
import android.widget.VideoView;

import com.arthenica.mobileffmpeg.FFmpeg;
import com.takisoft.datetimepicker.DatePickerDialog;
import com.takisoft.datetimepicker.TimePickerDialog;
import com.takisoft.datetimepicker.widget.DatePicker;
import com.takisoft.datetimepicker.widget.TimePicker;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.Calendar;
import java.util.regex.Pattern;

public class MainActivity extends AppCompatActivity {
    final Calendar cal = Calendar.getInstance();
    TextView startdate;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        startdate = findViewById(R.id.startdate);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final int[] sy = new int[1];
        final int[] sm = new int[1];
        final int[] sd = new int[1];
        final int[] smin = new int[1];
        final int[] sh = new int[1];
        final int[] ey = new int[1];
        final int[] em = new int[1];
        final int[] ed = new int[1];
        final int[] emin = new int[1];
        final int[] eh = new int[1];

        final VideoView vv = findViewById(R.id.videoView);
        findViewById(R.id.sdate).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final boolean[] timeDone = {false};
                DatePickerDialog dpd = new DatePickerDialog(MainActivity.this);
                dpd.setOnDateSetListener(new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {

                        boolean dateChange = false;


                        sy[0] = year;
                        sm[0] = month+1;
                        sd[0] = dayOfMonth;

                        Log.d(" PDP Date ", ""+sy[0] +","+ sm[0] +","+ sd[0]);
                        startdate = findViewById(R.id.startdate);
                        startdate.setText(String.format("Start Date Time: %02d %02d %04d ", sd[0],sm[0],sy[0]));
                    }
                });
                dpd.show();

            }
        });
        findViewById(R.id.stime).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TimePickerDialog.OnTimeSetListener myTimeListener = new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                        if (view.isShown()) {
                            smin[0] = minute;
                            sh[0] = hourOfDay;
                            cal.set(cal.YEAR, cal.MONTH, cal.DAY_OF_MONTH, hourOfDay, minute);

                            Log.d(" PDP Date ", ""+sy[0] +","+ sm[0] +","+ sd[0]+" "+ sh[0]+":"+sm[0]);
                            startdate = findViewById(R.id.startdate);
                            startdate.setText(String.format("Start Date Time: %02d %02d %04d %2d:%2d:00", sd[0],sm[0],sy[0], sh[0],sm[0]));
                        }
                    }
                };
                TimePickerDialog timePickerDialog = new TimePickerDialog(MainActivity.this, android.R.style.Theme_Holo_Light_Dialog_NoActionBar, myTimeListener,sh[0], smin[0], true);
                timePickerDialog.setTitle("Choose hour:");
                timePickerDialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
                timePickerDialog.show();

            }
        });

        findViewById(R.id.edate).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DatePickerDialog dpd = new DatePickerDialog(MainActivity.this);
                dpd.setOnDateSetListener(new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {

//                        cal.set(year, month+1, dayOfMonth);


                        ey[0] = year;
                        em[0] = month+1;
                        ed[0] = dayOfMonth;

                        Log.d(" PDP Date ", ""+ey[0] +","+ em[0] +","+ ed[0]);
                        startdate = findViewById(R.id.enddate);
                        startdate.setText(String.format("End Date Time: %02d %02d %04d", ed[0],em[0],ey[0]));
                    }
                });
                dpd.show();
            }
        });

        findViewById(R.id.etime).setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v) {
                TimePickerDialog.OnTimeSetListener myTimeListener = new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                        if (view.isShown()) {
                            emin[0] = minute;
                            eh[0] = hourOfDay;

                            Log.d(" PDP Date ", ""+ey[0] +","+ em[0] +","+ ed[0]+" "+ eh[0]+":"+em[0]);
                            startdate = findViewById(R.id.enddate);
                            startdate.setText(String.format("End Date Time: %02d %02d %04d %2d:%2d:00", ed[0],em[0],ey[0], eh[0],em[0]));
                        }
                    }
                };
                TimePickerDialog timePickerDialog = new TimePickerDialog(MainActivity.this, android.R.style.Theme_Holo_Light_Dialog_NoActionBar, myTimeListener,eh[0], emin[0], true);
                timePickerDialog.setTitle("Choose hour:");
                timePickerDialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
                timePickerDialog.show();
            }
        });

        findViewById(R.id.videoGenerate).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TextView vpath = findViewById(R.id.videopath);
                Calendar scal = Calendar.getInstance();
                scal.set(sy[0],sm[0],sd[0],sh[0],smin[0]);
                Calendar ecal = Calendar.getInstance();
                ecal.set(ey[0],em[0],ed[0],eh[0],emin[0]);
                Log.d(" DPD video function" , ""+scal.getTimeInMillis()+" ? "+ ecal.getTimeInMillis() );
                if(ecal.before(scal)){
                    vpath.setText(" DPD video function  Case not functioning " );
                    return;
                }
                Log.d(" DPD video function" , ""+scal.getTimeInMillis()+" ? "+ ecal.getTimeInMillis() );
                String path = ImageToVideo(scal.getTimeInMillis(), ecal.getTimeInMillis());
                //String path = ImageToVideo(1576825870989L, 1576825880473L);
                File check = new File(path);
                if(!check.exists()) return;
                MediaController mediaController = new MediaController(MainActivity.this);
                mediaController.setAnchorView(vv);
                vv.setMediaController(mediaController);
                vv.setVideoPath(path);
                vv.requestFocus();
                vv.start();
                vpath.setText( path );
            }
        });
/*
        Button b = findViewById(R.id.button);
        Button b2 = findViewById(R.id.button2);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(" BETST 1 ", ""+System.currentTimeMillis());
                generateFilesForVideo();
                Log.d(" BETST 4 ", ""+System.currentTimeMillis());
            }
        });
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(" BETST 5 ", ""+System.currentTimeMillis());
                AsyncTask.execute(new Runnable() {
                    @Override
                    public void run() {
                        VideoRecord.ImageToVideo(1576721357286L);
                    }
                });
                Log.d(" BETST 6 ", ""+System.currentTimeMillis());
            }
        });

        */
    }

    String path = Environment.getExternalStorageDirectory().toString();
    File saveImage = new File(Environment.getExternalStorageDirectory() + "/ImgSave/");
    File saveVideo = new File(Environment.getExternalStorageDirectory() + "/VideoSave/");

    private static int result = -1;
    public void emptyFileForImageSave(){
        if(saveImage.exists()){
            File[] files = saveImage.listFiles();
            for(File is: files) is.delete();
        }else{
            saveImage.mkdir();
        }
/*
        if (!saveImage.exists()) {
            saveImage.mkdir();
        }
        if(!saveVideo.exists()){
            saveVideo.mkdir();
        }

        File directory = saveImage;
        File[] files = directory.listFiles();
        for(File is : files){
            is.delete();
        }
        directory = saveVideo;
        files = directory.listFiles();
        for(File is : files){
            is.delete();
        }
        */
    }
    public void generateFilesForVideo(){
        Log.d(" BETST 2 ", ""+System.currentTimeMillis());

        if(saveVideo.exists()){
            Log.d(" BETST ! ", ""+System.currentTimeMillis());
            File[] files = saveVideo.listFiles();
            Log.d(" BETST ! ", ""+files.length);
            for(File is : files) is.delete();


        }else{
            Log.d(" BETST ? ", ""+System.currentTimeMillis());
            saveVideo.mkdir();
        }
        Log.d(" BETST 3 ", ""+System.currentTimeMillis());
    }
    public void showHourPicker() {
        final Calendar myCalender = Calendar.getInstance();
        int hour = myCalender.get(Calendar.HOUR_OF_DAY);
        int minute = myCalender.get(Calendar.MINUTE);



    }

    public String ImageToVideo(long startTime, long endTime){
        String resultPath = "";
        String path = Environment.getExternalStorageDirectory().toString();
        File directory = new File(path+"/ImgSave/");
        File[] files = directory.listFiles(new FilenameFilter() {
            @Override
            public boolean accept(File dir, String name) {
                //return Pattern.matches(String.format("(%s|%s|%s|%s|%s)[0-9]{4}.jpg",current, prevos,future,prevos1,future1),name);
               Log.d(" Nameot",dir+ name);
                if(!name.contains(".")){
                    Log.d(" Nameot", "false: " + name);
                    return false;
                }else{
                    long timestamp = Long.valueOf(name.substring(0,name.lastIndexOf(".")));
                    Log.d(" Nameot ", name.split("//.")[0] + (timestamp > startTime && timestamp < endTime));
                    Log.d(" Nameot  Value ", ""+timestamp+" > " + startTime + " && " + timestamp + " < " + endTime);
                    return timestamp > startTime && timestamp < endTime;
                }



            }
        });
        int i = 0;
        Log.d(" Nameot ", "Size: "+files.length);
        if(files == null){
            Log.d(" Nameot", "No files Size:" + files.length);
            return resultPath;
        }
        //Log.d(" OK123 care ", "Start Video"+ files.length);
        for(File f : files){
            //cmdFile += (f +"|");
            //Log.d( " OK123 ", ""+f );
            if(f != null) {
                Log.d(" Nameot", "true");
                fileMove(f, new File(path + "/VideoSave/" + String.format("%03d", (i++)) + ".jpg"));
            }else{
                Log.d(" Nameot", "false");
            }


            //f.renameTo(new File(path+"/VideoSave/"+String.format("%03d",(i++))+".jpg"));
            //int rc = FFmpeg.execute("-y","-framerate", "14","pattern_type", "glob","-i", path+"*.jpg", ""+Environment.getExternalStorageDirectory()+"/Download/output1.mp4");
            //Log.d(" OK12 ", String.format("Command execution %s.", (rc == 0?"completed successfully":"failed with rc=" + rc)));
        }
        resultPath = ""+ Environment.getExternalStorageDirectory()+"/Download/"+startTime+"-"+endTime+".mp4";
        int rc = FFmpeg.execute("-y","-framerate", "16","-i",
                ""+ Environment.getExternalStorageDirectory()+"/VideoSave/%03d.jpg",
                resultPath);
        if(rc!=0) return "";
        return resultPath;
    }
    public void fileMove(File sourcePath, File destPath){
        InputStream in = null;
        OutputStream out = null;
        File sourceParent = sourcePath.getParentFile();
        File destParent = destPath.getParentFile();
        if(!sourceParent.exists()){
            sourceParent.mkdir();
        }if(! destParent.exists()){
            destParent.mkdir();
        }
        try {
            in = new FileInputStream(sourcePath);
            out = new FileOutputStream(destPath);
            byte[] buffer = new byte[1024];
            int read;
            while ((read = in.read(buffer)) != -1) {
                out.write(buffer, 0, read);
            }
            in.close();
            in = null;
            out.flush();
            out.close();
            out = null;
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }


}
