package com.example.ffmpeg;

import android.os.Environment;
import android.util.Log;

import com.arthenica.mobileffmpeg.FFmpeg;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.regex.Pattern;

public class VideoRecord {
    public static void ImageToVideo(long currenTime){

        String n = ""+currenTime;
        final String current, prevos, future;//, prevos1, future1;
        currenTime/=10000;
        current = String.valueOf(currenTime).trim();
        prevos = String.valueOf(currenTime -1L).trim();
        future = String.valueOf(currenTime +1L).trim();
/*

        prevos1 = String.valueOf(currenTime -2L).trim();
        future1 = String.valueOf(currenTime +2L).trim();
*/

     String path = Environment.getExternalStorageDirectory().toString();
        File directory = new File(path+"/ImgSave/");
        Log.d(" OK123 for ", current +"," + prevos +", " + future);
        File[] files = directory.listFiles(new FilenameFilter() {
            @Override
            public boolean accept(File dir, String name) {
                //return Pattern.matches(String.format("(%s|%s|%s|%s|%s)[0-9]{4}.jpg",current, prevos,future,prevos1,future1),name);
                return Pattern.matches(String.format("(%s|%s|%s)[0-9]{4}.jpg",current, prevos,future),name);
            }
        });
        int i = 0;
        if(files == null) return;
        //Log.d(" OK123 care ", "Start Video"+ files.length);
        for(File f : files){
            //cmdFile += (f +"|");
            //Log.d( " OK123 ", ""+f );
            if(f != null)
                fileMove(f, new File(path+"/VideoSave/"+ String.format("%03d",(i++))+".jpg"));
            //f.renameTo(new File(path+"/VideoSave/"+String.format("%03d",(i++))+".jpg"));
            //int rc = FFmpeg.execute("-y","-framerate", "14","pattern_type", "glob","-i", path+"*.jpg", ""+Environment.getExternalStorageDirectory()+"/Download/output1.mp4");
            //Log.d(" OK12 ", String.format("Command execution %s.", (rc == 0?"completed successfully":"failed with rc=" + rc)));
        }
        int rc = FFmpeg.execute("-y","-framerate", "16","-i",
                ""+ Environment.getExternalStorageDirectory()+"/VideoSave/%03d.jpg",
                ""+ Environment.getExternalStorageDirectory()+"/Download/"+n+".mp4");


        //int rc = FFmpeg.execute("-y","-framerate", "14","-i",cmdFile , ""+Environment.getExternalStorageDirectory()+"/Download/output1.mp4");

    }
    public static void fileMove(File sourcePath, File destPath){
        InputStream in = null;
        OutputStream out = null;
        File sourceParent = sourcePath.getParentFile();
        File destParent = destPath.getParentFile();
        if(!sourceParent.exists()){
            sourceParent.mkdir();
        }if(! destParent.exists()){
            destParent.mkdir();
        }
        try {
            in = new FileInputStream(sourcePath);
            out = new FileOutputStream(destPath);
            byte[] buffer = new byte[1024];
            int read;
            while ((read = in.read(buffer)) != -1) {
                out.write(buffer, 0, read);
            }
            in.close();
            in = null;
            out.flush();
            out.close();
            out = null;
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    public static void saveSessionVideo(){
        String path = Environment.getExternalStorageDirectory().toString();
        int n = 0;
        File saveVideo = new File(path +"/ImgSave/");
        File[] files = saveVideo.listFiles();
        for(File is: files) is.renameTo(new File(path+"/VideoSave/"+ String.format("%06d",(n++))+".jpg"));
        int rc = FFmpeg.execute("-y","-framerate", "16","-i",
                ""+path+"/VideoSave/%06d.jpg",
                ""+path+"/Download/SessionVideo"+ System.currentTimeMillis()+".mp4");
    }

}
